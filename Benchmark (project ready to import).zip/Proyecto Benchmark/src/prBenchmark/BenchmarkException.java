package prBenchmark;

public class BenchmarkException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BenchmarkException() {
		super();
	}

	public BenchmarkException(String string) {
		super(string);
	}

}
