package prBenchmark;

public class StressTest {

}
